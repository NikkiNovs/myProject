import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-knobs',
  templateUrl: './knobs.component.html',
  styleUrls: ['./knobs.component.css']
})
export class KnobsComponent {
  @Input() textBtn: string='';
  @Input() widBtn: string='';
  constructor() { }

}
