import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.css']
})
export class PageComponent implements OnInit {

  constructor() { }
  arr=[
    {photo:'./assets/Vector.png', name:'TOUR ', size:'22px', navi:'/'},
    {photo:'./assets/Vector2.png', name:'DESIGNERS',size: '16px',navi:''},
    {photo:'./assets/Vector3.png', name:'BRANDS', size:'20.8px', navi:''},
    {photo:'./assets/Vector4.png', name:'ABOUT', size:'20px', navi:'/about'},
    {photo:'./assets/Vector5.png', name:'ENTER TO WIN',size:'22px', navi:''}
  ]
  ngOnInit(): void {
  }

}
