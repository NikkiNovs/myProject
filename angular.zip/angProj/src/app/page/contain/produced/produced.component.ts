import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-produced',
  templateUrl: './produced.component.html',
  styleUrls: ['./produced.component.css']
})
export class ProducedComponent implements OnInit {
produc=[
  {text:'PRODUCER', photo:'./assets/EmbelloLogos.png'},
  {text:'NATIONAL MEDIA PARTNER', photo:'./assets/LivingLogos.png'}

]
  constructor() { }

  ngOnInit(): void {
  }

}
