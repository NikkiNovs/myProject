import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meet',
  templateUrl: './meet.component.html',
  styleUrls: ['./meet.component.css']
})
export class MeetComponent implements OnInit {
  inst: string='./assets/inst.png'
designPeople=[
  {photo:'./assets/Rectangle1.png',firstName:'Anne Sage', profession:'NURSERY & BATH', linkInst:''},
  {photo:'./assets/Rectangle2.png',firstName:'Bobby Berk', profession:'ENTRY', professionTwo:'MUDROOM', linkInst:''},
  {photo:'./assets/Rectangle3.png',firstName:'Brittany Jepsen', profession:'CRAFT ROOM', linkInst:''},
  {photo:'./assets/Rectangle4.png',firstName:'Breegan Jane', profession:'KITCHEN & PANTRY', linkInst:''},
  {photo:'./assets/Rectangle5.png',firstName:'Kelly Finley', profession:'GUEST BEDROOM & BATH', linkInst:''},
  {photo:'./assets/Rectangle6.png',firstName:'Lori Paranjape', profession:'PLAYROOM', linkInst:''},
  {photo:'./assets/Rectangle7.png',firstName:'Marie Flanigan', profession:'PRIMARY BATH',professionTwo:'PRIMARY CLOSET', linkInst:''},
  {photo:'./assets/Rectangle8.png',firstName:'Mat Sanders', profession:'LOUNGE / BAR', linkInst:''},
  {photo:'./assets/Rectangle9.png',firstName:'Michael Smith Boyd', profession:'WELLNESS AREA',professionTwo:'MEDITATION DECK', linkInst:''},
  {photo:'./assets/Rectangle10.png',firstName:'Mikel Welch', profession:'PRIMARY BEDROOM', linkInst:''},
  {photo:'./assets/Rectangle11.png',firstName:'Nina Magon', profession:'DINING ROOM',professionTwo:'WINE ROOM', linkInst:''},
  {photo:'./assets/Rectangle12.png',firstName:'Rajni Alex', profession:'OFFICE', linkInst:''},
  {photo:'./assets/Rectangle13.png',firstName:'Sabrina Soto', profession:'PORCH LOUNGE',professionTwo:'POOL SURROUND', linkInst:''},
  {photo:'./assets/Rectangle14.png',firstName:'Saudah Saleem', profession:'PORCH LIVING', professionTwo:'PORCH DINING',linkInst:''},
  {photo:'./assets/Rectangle15.png',firstName:'Shea McGee', profession:'GREAT ROOM', linkInst:''},
  {photo:'./assets/Rectangle16.png',firstName:'Vanessa Deleon', profession:'GUEST BEDROOM & BATH', linkInst:''},
  {photo:'./assets/Rectangle17.png',firstName:'Christopher Brandon', profession:'ARCHITECTURE', linkInst:''},
  {photo:'./assets/Rectangle18.png',firstName:'Cliff Fong', profession:'CABANA',professionTwo:'OUTDOOR DINING', linkInst:''},
  {photo:'./assets/Rectangle19.png',firstName:'Corey Damen Jenkins', profession:'GUEST BEDROOM & BATH', linkInst:''},
  {photo:'./assets/Rectangle20.png',firstName:'Fernando Wong', profession:'LANDSCAPE ARCHITECTURE', linkInst:''}

]
  constructor() { }

  ngOnInit(): void {
  }

}
