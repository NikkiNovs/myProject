import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-particip',
  templateUrl: './particip.component.html',
  styleUrls: ['./particip.component.css']
})
export class ParticipComponent implements OnInit {
arrSpons=['./assets/calico.png','./assets/BlackLogo.png','./assets/poly.png']
  constructor() { }

  ngOnInit(): void {
  }

}
