import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chance',
  templateUrl: './chance.component.html',
  styleUrls: ['./chance.component.css']
})
export class ChanceComponent implements OnInit {
icon: string='./assets/gift-line.png'
  constructor() { }

  ngOnInit(): void {
  }

}
