import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
arrLink=['Let’s get social', 'TERMS OF USE','PRIVACY POLICY','sweepstakes rules','CONTACT']
  constructor() { }

  ngOnInit(): void {
  }

}
