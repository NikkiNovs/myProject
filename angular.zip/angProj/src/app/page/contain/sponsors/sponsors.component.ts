import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sponsors',
  templateUrl: './sponsors.component.html',
  styleUrls: ['./sponsors.component.css']
})
export class SponsorsComponent implements OnInit {
arrIco=[
  {photo:'./assets/CalClosets.png', width:'255px'},
  {photo:'./assets/Carrier.png', width:'175px'},
  {photo:'./assets/Minted.png', width:'150px'},
  {photo:'./assets/mn.png', width:'200px'}
]
  constructor() { }

  ngOnInit(): void {
  }

}
