import {Component, OnInit, ViewChild, HostListener, ElementRef, Renderer2} from '@angular/core';
import {Subscription, timer} from 'rxjs'

@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {
  imgWatch:string='./assets/wt.png'

  constructor(private renderer: Renderer2) { }
  @ViewChild('noName') noName?: ElementRef;
  @ViewChild('timerBlock') timer?: ElementRef;
  @ViewChild('stiksBlock') sticks?: ElementRef;

  @HostListener('window: scroll')

  lipsStiks(){
    if(this.noName?.nativeElement.getBoundingClientRect().top<0){
      this.renderer.setStyle(this.timer?.nativeElement, 'display', 'none')
      this.renderer.setStyle(this.sticks?.nativeElement, 'display', 'flex')
    } else if(this.noName?.nativeElement.getBoundingClientRect().top>0){
      this.renderer.setStyle(this.timer?.nativeElement, 'display', '')
      this.renderer.setStyle(this.sticks?.nativeElement, 'display', '')
    }
  }

  arrTimes=[
    {name:'DAYS', first:'', second: ''},
    {name:'HRS', first:'' , second:''},
    {name:'MIN', first:'', second:''},
    {name:'SEC', first:'', second:''}
  ]
  date: any =new Date()
  dateNow: any=new Date(2022, 0, 25)
result: number=0;
  clock: any;
  source = timer(0, 1000);
  ngOnInit(): void {
    this.result=this.dateNow.getTime()/1000-this.date.getTime()/1000;
    this.clock = this.source.subscribe(t => {
      this.result--;
      this.times();
    });
  }
  times(){
    this.arrTimes[0].first=Math.trunc(this.result/3600/24%60).toString()
    this.arrTimes[1].first=Math.trunc(this.result/3600%24).toString()
    this.arrTimes[2].first=Math.trunc(this.result/60%60).toString()
    this.arrTimes[3].first=Math.trunc(this.result%60).toString()
  }
  }
