import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent {
  @Input() backFon: string='';
@Input() h2Text: string='';
  @Input() h2Text2: string='';
  @Input() textBtn: string='';
  @Input() heigBlock: string='';
  @Input() otstBtn: string='';
  @Input() imgFon: string='';
  @Input() imgLogo: string='';
  @Input() textUpp: string='';
    @Input() textLow: string='';
  @Input() textLow2: string='';
  @Input() wid: string='';
  @Input()widLogo: string='';


  inst: string='./assets/inst.png'
  link: string='./assets/Vector11.png'
  constructor() { }

}
