import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {HomeComponent} from "./page/contain/home/home.component";
import {MeetComponent} from "./page/contain/meet/meet.component";
import {TimesComponent} from "./page/contain/times/times.component";
import {TimerComponent} from "./page/contain/times/timer/timer.component";
import {ChanceComponent} from "./page/contain/chance/chance.component";
import {AboutComponent} from "./page/about/about.component";
import {SponsorsComponent} from "./page/contain/sponsors/sponsors.component";
import {ContainComponent} from "./page/contain/contain.component";
3
const routes: Routes = [
  {path: '', component: ContainComponent},
  {path: 'home', component: HomeComponent},
  {path: 'meet', component: MeetComponent},
  {path: 'times', component: TimesComponent},
  {path: 'timer', component: TimerComponent},
  {path: 'chance', component: ChanceComponent},
  {path: 'about', component: AboutComponent},
  {path:'sponsors', component: SponsorsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
