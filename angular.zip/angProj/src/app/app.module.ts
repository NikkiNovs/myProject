import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {PageComponent} from "./page/page.component";
import {ContainComponent} from "./page/contain/contain.component";
import {AboutComponent} from "./page/about/about.component";
import {KnobsComponent} from "./page/knobs/knobs.component";
import {TimesComponent} from "./page/contain/times/times.component";
import {TimerComponent} from "./page/contain/times/timer/timer.component";
import {SponsorsComponent} from "./page/contain/sponsors/sponsors.component";
import {ProducedComponent} from "./page/contain/produced/produced.component";
import {ParticipComponent} from "./page/contain/particip/particip.component";
import {MeetComponent} from "./page/contain/meet/meet.component";
import {HomeComponent} from "./page/contain/home/home.component";
import {FooterComponent} from "./page/contain/footer/footer.component";
import {ChanceComponent} from "./page/contain/chance/chance.component";
import {HeadComponent} from "./page/about/head/head.component";
import {InfoComponent} from "./page/about/info/info.component";
import {TeamComponent} from "./page/about/team/team.component";

// import {ContainModule} from "./page/page.module";

@NgModule({
  declarations: [
    AppComponent,
    ContainComponent,
    AboutComponent,
    KnobsComponent,
    PageComponent,
    TimesComponent,
    TimerComponent,
    SponsorsComponent,
    ProducedComponent,
    ParticipComponent,
    MeetComponent,
    HomeComponent,
    FooterComponent,
    ChanceComponent,
    HeadComponent,
    InfoComponent,
    TeamComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
